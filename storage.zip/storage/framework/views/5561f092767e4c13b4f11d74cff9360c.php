<div id="appWrapper" class="app">

    
    <aside id="sidebar" class="sidebar">

        
        <div class="sb-brand">
            <div class="sb-brand-icon">
                <i class="fa-solid fa-graduation-cap"></i>
            </div>
            <span class="sb-brand-text">MyLMS</span>
            <button id="sidebarCollapseBtn" class="sb-collapse-btn" title="Collapse sidebar">
                <i class="fa-solid fa-angles-left"></i>
            </button>
        </div>

        
        <div class="sb-role-pill">
            <i class="fa-solid fa-chalkboard-user me-1"></i>
            <span class="sb-label">Teacher Panel</span>
        </div>

        
        <nav class="sb-nav">

            
            <p class="sb-section-label"><span class="sb-label">Overview</span></p>
            <ul class="sb-list">
                <li>
                    <a href="<?php echo e(route('teacher.main')); ?>" title="Dashboard"
                       class="sb-link <?php echo e(request()->routeIs('teacher.main') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-gauge-high"></i></span>
                        <span class="sb-label">Dashboard</span>
                    </a>
                </li>
            </ul>

            
            <p class="sb-section-label"><span class="sb-label">Teaching</span></p>
            <ul class="sb-list">

                <li>
                    <a href="<?php echo e(route('teacherClass.view')); ?>" title="My Classes"
                       class="sb-link <?php echo e(request()->routeIs('teacherClass.view') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-chalkboard"></i></span>
                        <span class="sb-label">My Classes</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('manageLessons.view')); ?>" title="Manage Lessons"
                       class="sb-link <?php echo e(request()->routeIs('manageLessons.view') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-list-check"></i></span>
                        <span class="sb-label">Manage Lessons</span>
                    </a>
                </li>

                <li class="sb-has-sub">
                    <button class="sb-link sb-toggle <?php echo e(request()->routeIs('createOnlineClass.view','recordedLeacture.view') ? 'sb-open' : ''); ?>"
                            data-target="#subLive">
                        <span class="sb-icon"><i class="fa-solid fa-video"></i></span>
                        <span class="sb-label">Live Sessions</span>
                        <i class="fa-solid fa-chevron-right sb-arrow"></i>
                    </button>
                    <ul class="sb-sub <?php echo e(request()->routeIs('createOnlineClass.view','recordedLeacture.view') ? 'show' : ''); ?>" id="subLive">
                        <li>
                            <a href="<?php echo e(route('createOnlineClass.view')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('createOnlineClass.view') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-circle-play"></i>Schedule Class
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('recordedLeacture.view')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('recordedLeacture.view') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-film"></i>Recorded Lectures
                            </a>
                        </li>
                    </ul>
                </li>

            </ul>

            
            <p class="sb-section-label"><span class="sb-label">Assignments</span></p>
            <ul class="sb-list">

                <li>
                    <a href="<?php echo e(route('teacher.assignments.uplodaView')); ?>" title="Upload Assignment"
                       class="sb-link <?php echo e(request()->routeIs('teacher.assignments.uplodaView') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-file-arrow-up"></i></span>
                        <span class="sb-label">Upload Assignment</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('assignmentReviews.view')); ?>" title="Assignment Reviews"
                       class="sb-link <?php echo e(request()->routeIs('assignmentReviews.view') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-clipboard-check"></i></span>
                        <span class="sb-label">Review & Grade</span>
                    </a>
                </li>

            </ul>

            
            <p class="sb-section-label"><span class="sb-label">Resources</span></p>
            <ul class="sb-list">

                <li>
                    <a href="<?php echo e(route('uploadMaterials.view')); ?>" title="Upload Materials"
                       class="sb-link <?php echo e(request()->routeIs('uploadMaterials.view') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-folder-open"></i></span>
                        <span class="sb-label">Upload Materials</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('stdGradeUpload.view')); ?>" title="Bulk Grade Upload"
                       class="sb-link <?php echo e(request()->routeIs('stdGradeUpload.view') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-upload"></i></span>
                        <span class="sb-label">Bulk Grade Upload</span>
                    </a>
                </li>

            </ul>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage-students', 'role-manage'])): ?>
            <p class="sb-section-label"><span class="sb-label">Access</span></p>
            <ul class="sb-list">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-students')): ?>
                <li>
                    <a href="<?php echo e(route('teacher.student.managment')); ?>" title="Students"
                       class="sb-link <?php echo e(request()->routeIs('teacher.student.managment') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-user-graduate"></i></span>
                        <span class="sb-label">Students</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-manage')): ?>
                <li>
                    <a href="<?php echo e(route('teacher.role')); ?>" title="Roles"
                       class="sb-link <?php echo e(request()->routeIs('teacher.role') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-user-shield"></i></span>
                        <span class="sb-label">Roles</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
            <?php endif; ?>

        </nav>

        
        <div class="sb-profile">
            <div class="sb-profile-avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></div>
            <div class="sb-profile-info sb-label">
                <p class="sb-profile-name"><?php echo e(auth()->user()->name); ?></p>
                <p class="sb-profile-role">Teacher</p>
            </div>
            <form action="<?php echo e(route('logout')); ?>" method="POST" class="sb-label">
                <?php echo csrf_field(); ?>
                <button type="submit" class="sb-logout-btn" title="Sign out">
                    <i class="fa-solid fa-right-from-bracket"></i>
                </button>
            </form>
        </div>

    </aside>

    
    <header class="app-header" role="banner">
        <div class="header-left">
            <button id="mobileMenuBtn" class="hdr-icon-btn d-lg-none" type="button" aria-label="Open menu">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="search-input">
                <i class="fa-solid fa-magnifying-glass hdr-search-icon"></i>
                <input class="hdr-search-field" type="search" placeholder="Search..." aria-label="Search" />
            </div>
        </div>

        <div class="header-right">
            <button class="hdr-icon-btn" title="Notifications">
                <i class="fa-solid fa-bell"></i>
            </button>

            <div class="hdr-divider"></div>

            <div class="dropdown">
                <button class="hdr-profile-btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="hdr-avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></div>
                    <span class="hdr-name d-none d-md-inline"><?php echo e(auth()->user()->name); ?></span>
                    <i class="fa-solid fa-chevron-down hdr-caret d-none d-md-inline"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end hdr-dropdown">
                    <li class="hdr-dd-user">
                        <div class="hdr-dd-avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></div>
                        <div>
                            <div class="hdr-dd-name"><?php echo e(auth()->user()->name); ?></div>
                            <div class="hdr-dd-email"><?php echo e(auth()->user()->email); ?></div>
                        </div>
                    </li>
                    <li><hr class="dropdown-divider my-1"></li>
                    <li>
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="dropdown-item hdr-dd-item text-danger">
                                <i class="fa-solid fa-right-from-bracket me-2"></i>Sign out
                            </button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    
    <div id="sidebarOverlay" class="sb-overlay"></div>
<?php /**PATH D:\LMS\resources\views/partials/sidebar/teacher.blade.php ENDPATH**/ ?>