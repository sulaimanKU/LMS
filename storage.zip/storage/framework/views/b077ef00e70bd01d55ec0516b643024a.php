<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>

<div class="app-wrapper">

    <?php if(auth()->guard()->check()): ?>
        <?php

            $role = auth()->user()->getRoleNames()->first() ?? 'default';
        ?>

        <?php if ($__env->exists('partials.sidebar.' . $role)) echo $__env->make('partials.sidebar.' . $role, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

    <main class="main-content">
        <?php echo $__env->yieldContent('contents'); ?>
    </main>

</div>

<?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH D:\LMS\resources\views/applayouts/app.blade.php ENDPATH**/ ?>