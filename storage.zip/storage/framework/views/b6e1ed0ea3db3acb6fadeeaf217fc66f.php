<?php $__env->startSection('contents'); ?>

    
    <div class="d-block w-100" style="height: 80px;"></div>

    <div class="container-fluid px-md-4">

        
        <div class="row mb-4 align-items-center">
            <div class="col-12 col-md-6">
                <h4 class="fw-bold text-dark mb-1">Curriculum Management</h4>
                <p class="text-muted small mb-0">List of all lessons and modules</p>
            </div>
            <div class="col-12 col-md-6 text-md-end mt-2 mt-md-0">
                <button class="btn btn-primary px-4 fw-bold shadow-sm" data-bs-toggle="modal"
                    data-bs-target="#createLessonModal">
                    <i class="fas fa-plus me-1"></i> New Lesson
                </button>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success border-0 shadow-sm mb-4">
                <i class="fas fa-check-circle me-2"></i> <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

<?php if($myModules->count() > 0): ?>
    <div class="row mb-4">
        <?php $__currentLoopData = $myModules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mb-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-3">

                        <div class="d-flex justify-content-between align-items-center">
                            <h6 class="fw-bold mb-0 text-dark">
                                <?php echo e($module->title); ?>

                            </h6>

                            <span class="badge bg-primary bg-opacity-10 text-primary">
                                Module
                            </span>
                        </div>

                        <p class="text-muted small mt-2 mb-2">
                            <?php echo e($module->short_description ?? 'No description'); ?>

                        </p>

                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <small class="text-muted">
                                <?php echo e($module->duration ?? '--'); ?>

                            </small>

                            <button class="btn btn-sm btn-outline-primary"
                                data-bs-toggle="modal"
                                data-bs-target="#createLessonModal">
                                Add Lesson
                            </button>
                        </div>

                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
    <div class="alert alert-warning mb-4">
        No modules assigned to you yet.
    </div>
<?php endif; ?>
        <div class="card border-0 shadow-sm overflow-hidden">

            <div class="table-responsive p-3">
                <table class="table table-hover align-middle mb-0" id="studentTable">
                    <thead class="bg-light">
                        <tr class="small text-muted">
                            <th class="border-0 ps-3">#</th>
                            <th class="border-0">Module</th>
                            <th class="border-0">Title</th>
                            <th class="border-0">Access</th>
                            <th class="border-0 text-center">Video</th>
                            <th class="border-0 text-end pe-3">Actions</th>
                        </tr>
                    </thead>
                   <tbody class="border-top-0">
    <?php $__empty_1 = true; $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            
            <td class="ps-3 text-muted"><?php echo e($lesson->order_number); ?></td>

            
            <td>
                <span class="badge bg-primary bg-opacity-10 text-primary border-0">
                    <?php echo e($lesson->module->title ?? 'N/A'); ?>

                </span>
                <span class="badge bg-dark bg-opacity-10 text-dark border-0">
                    
                    <i class="fas fa-user-tie me-1"></i> <?php echo e(auth()->user()->name); ?>

                </span>
            </td>

            
            <td>
                <div class="fw-bold mb-0 text-dark"><?php echo e($lesson->title); ?></div>
                <small class="text-muted" style="font-size: 10px;"><?php echo e($lesson->slug); ?></small>
            </td>

            
            <td>
                <?php if($lesson->is_preview): ?>
                    <span class="badge bg-success bg-opacity-10 text-success border-0">Free</span>
                <?php else: ?>
                    <span class="badge bg-secondary bg-opacity-10 text-secondary border-0">Paid</span>
                <?php endif; ?>
            </td>

            
            <td class="text-center">
                <?php if($lesson->documnet_path): ?>
                    <a href="<?php echo e($lesson->documnet_path); ?>" target="_blank" class="text-danger">
                        <i class="fab fa-youtube fs-5"></i>
                    </a>
                <?php else: ?>
                    <span class="text-muted small">---</span>
                <?php endif; ?>
            </td>

            
            <td class="text-end pe-3">
                <button type="button"
                    class="btn btn-sm btn-outline-primary border-0 edit-lesson-btn"
                    data-id="<?php echo e($lesson->id); ?>"
                    data-title="<?php echo e($lesson->title); ?>"
                    data-short="<?php echo e($lesson->short_text); ?>"
                    data-order="<?php echo e($lesson->order_number); ?>"
                    data-video="<?php echo e($lesson->documnet_path); ?>"
                    data-content="<?php echo e($lesson->full_content); ?>"
                    data-module="<?php echo e($lesson->module_id); ?>"
                    data-bs-toggle="modal"
                    data-bs-target="#editLessonModal">
                    <i class="fas fa-edit"></i>
                </button>

                <form action="<?php echo e(route('teacher.lessons.destroy', $lesson->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-outline-danger border-0"
                        onclick="return confirm('Are you sure you want to delete this lesson?')">
                        <i class="fas fa-trash"></i>
                    </button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6" class="text-center py-5">
                <div class="text-muted">
                    <i class="fas fa-folder-open fa-3x mb-3 opacity-25"></i>
                    <p>No lessons found. Start by adding a new lesson to your courses!</p>
                </div>
            </td>
        </tr>
    <?php endif; ?>
</tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="createLessonModal" tabindex="-1" aria-hidden="true" style="z-index: 2000;">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header border-0 pb-0">
                    <h6 class="fw-bold mb-0">Add New Lesson</h6>
                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('teacher.lessons.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-9">
                                <label class="form-label small text-muted mb-1">Module</label>
                                <select name="module_id" class="form-select border-0 bg-light shadow-none" required>
                                    <option value="" selected disabled>Select Module</option>
                                    <?php $__currentLoopData = $myModules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($module->id); ?>"><?php echo e($module->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small text-muted mb-1">Order #</label>
                                <input type="number" name="order_number" class="form-control border-0 bg-light shadow-none"
                                    value="1" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label small text-muted mb-1">Lesson Title</label>
                                <input type="text" name="title" class="form-control border-0 bg-light shadow-none"
                                    required>
                            </div>
                            <div class="col-12">
                                <label class="form-label small text-muted mb-1">Short Summary (Optional)</label>
                                <input type="text" name="short_text" class="form-control border-0 bg-light shadow-none"
                                    placeholder="Brief description...">
                            </div>
                            <div class="col-12">
                                <label class="form-label small text-muted mb-1">Video URL</label>
                                <input type="url" name="documnet_path"
                                    class="form-control border-0 bg-light shadow-none" placeholder="YouTube/Vimeo link">
                            </div>
                            <div class="col-12">
                                <label class="form-label small text-muted mb-1">Full Content</label>
                                <textarea name="full_content" rows="4" class="form-control border-0 bg-light shadow-none"
                                    placeholder="Lesson details..."></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-0 pt-0">
                        <button type="button" class="btn btn-light btn-sm text-muted px-3"
                            data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary btn-sm px-4 shadow-sm">Save Lesson</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editLessonModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header border-0 pb-0">
                    <h6 class="fw-bold mb-0">Edit Lesson</h6>
                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal"></button>
                </div>
                
                <form id="editLessonForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label small text-muted mb-1">Module</label>
                                <select name="module_id" id="edit_module_id" class="form-select border-0 bg-light"
                                    required>
                                    <?php $__currentLoopData = $myModules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($module->id); ?>"><?php echo e($module->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small text-muted mb-1">Order #</label>
                                <input type="number" name="order_number" id="edit_order_number"
                                    class="form-control border-0 bg-light">
                            </div>
                            <div class="col-12">
                                <label class="form-label small text-muted mb-1">Lesson Title</label>
                                <input type="text" name="title" id="edit_title"
                                    class="form-control border-0 bg-light" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label small text-muted mb-1">Video URL</label>
                                <input type="url" name="documnet_path" id="edit_video_url"
                                    class="form-control border-0 bg-light">
                            </div>
                            <div class="col-12">
                                <label class="form-label small text-muted mb-1">Short Description</label>
                                <textarea name="short_text" id="edit_short_text" rows="2" class="form-control border-0 bg-light"></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label small text-muted mb-1">Long Description</label>
                                <textarea name="full_content" id="edit_full_content" rows="2" class="form-control border-0 bg-light"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-0 pt-0">
                        <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-sm btn-primary px-4">Update Lesson</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const editBtns = document.querySelectorAll('.edit-lesson-btn');
            const editForm = document.getElementById('editLessonForm');

            editBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    const title = this.getAttribute('data-title');
                    const short = this.getAttribute('data-short');
                    const long = this.getAttribute('data-content');
                    const order = this.getAttribute('data-order');
                    const video = this.getAttribute('data-video');
                    const moduleId = this.getAttribute('data-module');


                    editForm.action = `/teacher/lessons/update/${id}`;


                    document.getElementById('edit_title').value = title;
                    document.getElementById('edit_short_text').value = short;
                    document.getElementById('edit_order_number').value = order;
                    document.getElementById('edit_video_url').value = video;
                    document.getElementById('edit_module_id').value = moduleId;
                    document.getElementById('edit_full_content').value = long;
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('applayouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LMS\resources\views/teacherLayouts/manageLessonsView.blade.php ENDPATH**/ ?>