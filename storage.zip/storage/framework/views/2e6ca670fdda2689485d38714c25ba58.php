<?php $__env->startSection('contents'); ?>

<?php
    $months = $monthlyData->keys()->toArray();
    $counts = $monthlyData->values()->toArray();
?>

<div class="dash-page">

    
    <div class="dash-topbar">
        <div>
            <h5 class="dash-title">Dashboard</h5>
            <p class="dash-subtitle">Welcome back, <?php echo e(auth()->user()->name); ?></p>
        </div>
        <a href="<?php echo e(route('admin.student.managment')); ?>" class="dash-action-btn">
            <i class="fa-solid fa-user-plus me-1"></i> Review Registrations
            <?php if($pendingCount > 0): ?>
                <span class="dash-badge"><?php echo e($pendingCount); ?></span>
            <?php endif; ?>
        </a>
    </div>

    
    <div class="dash-stats-grid">

        <div class="dstat-card" style="--accent-h: #4F46E5; --accent-s: #EEF2FF;">
            <div class="dstat-icon" style="background:#EEF2FF; color:#4F46E5;">
                <i class="fa-solid fa-user-graduate"></i>
            </div>
            <div class="dstat-body">
                <p class="dstat-label">Enrolled Students</p>
                <h3 class="dstat-num"><?php echo e($totalStudents); ?></h3>
            </div>
            <a href="<?php echo e(route('admin.student.managment')); ?>" class="dstat-link">View <i class="fa-solid fa-arrow-right ms-1"></i></a>
        </div>

        <div class="dstat-card" style="--accent-h:#7C3AED; --accent-s:#F5F3FF;">
            <div class="dstat-icon" style="background:#F5F3FF; color:#7C3AED;">
                <i class="fa-solid fa-chalkboard-user"></i>
            </div>
            <div class="dstat-body">
                <p class="dstat-label">Teachers</p>
                <h3 class="dstat-num"><?php echo e($totalTeachers); ?></h3>
            </div>
            <a href="<?php echo e(route('teacher.Mangment.View')); ?>" class="dstat-link">View <i class="fa-solid fa-arrow-right ms-1"></i></a>
        </div>

        <div class="dstat-card" style="--accent-h:#0891B2; --accent-s:#ECFEFF;">
            <div class="dstat-icon" style="background:#ECFEFF; color:#0891B2;">
                <i class="fa-solid fa-book-open"></i>
            </div>
            <div class="dstat-body">
                <p class="dstat-label">Active Modules</p>
                <h3 class="dstat-num"><?php echo e($totalCourses); ?></h3>
            </div>
            <a href="<?php echo e(route('course.index')); ?>" class="dstat-link">View <i class="fa-solid fa-arrow-right ms-1"></i></a>
        </div>

        <div class="dstat-card <?php echo e($pendingCount > 0 ? 'dstat-alert' : ''); ?>" style="--accent-h:#D97706; --accent-s:#FFFBEB;">
            <div class="dstat-icon" style="background:#FFFBEB; color:#D97706;">
                <i class="fa-solid fa-clock-rotate-left"></i>
            </div>
            <div class="dstat-body">
                <p class="dstat-label">Pending Approvals</p>
                <h3 class="dstat-num"><?php echo e($pendingCount); ?></h3>
            </div>
            <a href="<?php echo e(route('admin.student.managment')); ?>" class="dstat-link">Review <i class="fa-solid fa-arrow-right ms-1"></i></a>
        </div>

    </div>

    
    <div class="dash-main-grid">

        
        <div class="dash-card dash-chart-card">
            <div class="dash-card-header">
                <span class="dash-card-title"><i class="fa-solid fa-chart-line me-2 text-primary"></i>New Registrations — Last 6 Months</span>
            </div>
            <div class="dash-card-body" style="height:260px; padding:.75rem 1rem 1rem;">
                <canvas id="regChart"></canvas>
            </div>
        </div>

        
        <div class="dash-card dash-chart-card">
            <div class="dash-card-header">
                <span class="dash-card-title"><i class="fa-solid fa-circle-nodes me-2 text-purple"></i>User Distribution</span>
            </div>
            <div class="dash-card-body" style="height:260px; display:flex; align-items:center; justify-content:center; padding:1rem;">
                <canvas id="distChart"></canvas>
            </div>
        </div>

    </div>

    
    <div class="dash-card mt-4">
        <div class="dash-card-header">
            <span class="dash-card-title"><i class="fa-solid fa-list-check me-2 text-primary"></i>Recent Registrations</span>
            <a href="<?php echo e(route('admin.student.managment')); ?>" class="dash-view-all">View all</a>
        </div>
        <div class="dash-card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover dash-table mb-0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Modules</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentRegistrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="dash-avatar"><?php echo e(strtoupper(substr($reg->name, 0, 1))); ?></div>
                                    <span class="fw-semibold" style="font-size:.875rem;"><?php echo e($reg->name); ?></span>
                                </div>
                            </td>
                            <td style="font-size:.82rem; color:#64748B;"><?php echo e($reg->email); ?></td>
                            <td>
                                <span class="dash-pill"><?php echo e(count($reg->selected_courses)); ?> module<?php echo e(count($reg->selected_courses) !== 1 ? 's' : ''); ?></span>
                            </td>
                            <td style="font-size:.875rem; font-weight:600;">PKR <?php echo e(number_format($reg->total_amount, 0)); ?></td>
                            <td>
                                <?php if($reg->status === 'approved'): ?>
                                    <span class="dash-status dash-status-approved">Approved</span>
                                <?php else: ?>
                                    <span class="dash-status dash-status-pending">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td style="font-size:.78rem; color:#94A3B8;"><?php echo e($reg->created_at->format('d M Y')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4" style="font-size:.875rem;">
                                No registrations yet.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<style>
/* ── Page wrapper ── */
.dash-page {
    padding: 1.5rem;
    min-height: 100%;
    background: #F8FAFF;
}

/* ── Top bar ── */
.dash-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 1rem;
    margin-bottom: 1.75rem;
}
.dash-title    { font-size: 1.3rem; font-weight: 800; color: #1E293B; margin: 0; line-height: 1.2; }
.dash-subtitle { font-size: .82rem; color: #64748B; margin: .15rem 0 0; }

.dash-action-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: linear-gradient(135deg, #4F46E5, #7C3AED);
    color: #fff;
    padding: .5rem 1.1rem;
    border-radius: 8px;
    font-size: .85rem;
    font-weight: 600;
    text-decoration: none;
    box-shadow: 0 4px 14px rgba(79,70,229,.3);
    transition: all .2s;
    position: relative;
}
.dash-action-btn:hover { transform: translateY(-1px); color: #fff; box-shadow: 0 6px 20px rgba(79,70,229,.4); }
.dash-badge {
    background: #EF4444;
    color: #fff;
    border-radius: 50px;
    padding: 1px 7px;
    font-size: .7rem;
    font-weight: 700;
    margin-left: 2px;
}

/* ── Stat grid ── */
.dash-stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
    margin-bottom: 1.5rem;
}
.dstat-card {
    background: #fff;
    border-radius: 14px;
    padding: 1.25rem 1.25rem 1rem;
    box-shadow: 0 1px 6px rgba(0,0,0,.06);
    display: flex;
    flex-direction: column;
    gap: .5rem;
    border: 1.5px solid #F1F5F9;
    transition: box-shadow .2s, transform .2s;
}
.dstat-card:hover { box-shadow: 0 6px 20px rgba(0,0,0,.1); transform: translateY(-2px); }
.dstat-card.dstat-alert { border-color: #FCD34D; background: #FFFDF0; }

.dstat-icon {
    width: 44px; height: 44px;
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.1rem;
    flex-shrink: 0;
}
.dstat-body { flex: 1; }
.dstat-label { font-size: .72rem; font-weight: 600; text-transform: uppercase; letter-spacing: .7px; color: #94A3B8; margin: 0 0 .15rem; }
.dstat-num   { font-size: 2rem; font-weight: 800; color: #1E293B; margin: 0; line-height: 1.1; }
.dstat-link  { font-size: .75rem; font-weight: 600; color: #4F46E5; text-decoration: none; display: flex; align-items: center; }
.dstat-link:hover { color: #3730A3; }

/* ── Main grid (charts) ── */
.dash-main-grid {
    display: grid;
    grid-template-columns: 1fr 380px;
    gap: 1rem;
    margin-bottom: 0;
}

/* ── Card ── */
.dash-card {
    background: #fff;
    border-radius: 14px;
    box-shadow: 0 1px 6px rgba(0,0,0,.06);
    border: 1.5px solid #F1F5F9;
    overflow: hidden;
}
.dash-card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: .9rem 1.25rem;
    border-bottom: 1px solid #F1F5F9;
}
.dash-card-title { font-size: .88rem; font-weight: 700; color: #1E293B; }
.dash-view-all   { font-size: .78rem; font-weight: 600; color: #4F46E5; text-decoration: none; }
.dash-view-all:hover { color: #3730A3; }
.dash-card-body  { padding: 1.25rem; }

/* ── Table ── */
.dash-table thead th {
    font-size: .72rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .6px;
    color: #94A3B8;
    border-bottom: 1px solid #F1F5F9;
    background: #F8FAFF;
    padding: .7rem 1rem;
}
.dash-table tbody td { padding: .7rem 1rem; vertical-align: middle; border-bottom: 1px solid #F8FAFF; }
.dash-table tbody tr:last-child td { border-bottom: none; }

.dash-avatar {
    width: 30px; height: 30px;
    border-radius: 50%;
    background: linear-gradient(135deg,#4F46E5,#7C3AED);
    color: #fff;
    display: flex; align-items: center; justify-content: center;
    font-size: .75rem; font-weight: 700;
    flex-shrink: 0;
}

.dash-pill {
    background: #EEF2FF;
    color: #4F46E5;
    padding: .18rem .65rem;
    border-radius: 50px;
    font-size: .75rem;
    font-weight: 600;
}

.dash-status {
    display: inline-block;
    padding: .2rem .65rem;
    border-radius: 50px;
    font-size: .72rem;
    font-weight: 700;
    letter-spacing: .3px;
}
.dash-status-approved { background: #D1FAE5; color: #065F46; }
.dash-status-pending  { background: #FEF3C7; color: #92400E; }

.text-purple { color: #7C3AED; }

/* ── Responsive ── */
@media (max-width: 1199.98px) {
    .dash-stats-grid  { grid-template-columns: repeat(2, 1fr); }
    .dash-main-grid   { grid-template-columns: 1fr; }
}
@media (max-width: 575.98px) {
    .dash-page        { padding: 1rem .75rem; }
    .dash-stats-grid  { grid-template-columns: 1fr 1fr; gap: .6rem; }
    .dstat-num        { font-size: 1.6rem; }
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
(function () {
    const months = <?php echo json_encode($months, 15, 512) ?>;
    const counts = <?php echo json_encode($counts, 15, 512) ?>;

    // ── Line chart: registrations per month ──
    new Chart(document.getElementById('regChart'), {
        type: 'line',
        data: {
            labels: months.length ? months : ['No data'],
            datasets: [{
                label: 'Registrations',
                data: counts.length ? counts : [0],
                borderColor: '#4F46E5',
                backgroundColor: 'rgba(79,70,229,.08)',
                borderWidth: 2.5,
                pointBackgroundColor: '#4F46E5',
                pointRadius: 4,
                pointHoverRadius: 6,
                tension: 0.4,
                fill: true,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: { mode: 'index', intersect: false }
            },
            scales: {
                x: { grid: { display: false }, ticks: { font: { size: 11 } } },
                y: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 11 } }, grid: { color: '#F1F5F9' } }
            }
        }
    });

    // ── Doughnut chart: user distribution ──
    new Chart(document.getElementById('distChart'), {
        type: 'doughnut',
        data: {
            labels: ['Students', 'Teachers', 'Pending'],
            datasets: [{
                data: [<?php echo e($totalStudents); ?>, <?php echo e($totalTeachers); ?>, <?php echo e($pendingCount); ?>],
                backgroundColor: ['#4F46E5', '#7C3AED', '#F59E0B'],
                borderWidth: 0,
                hoverOffset: 6,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '72%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { font: { size: 12 }, padding: 16, usePointStyle: true }
                }
            }
        }
    });
})();
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('applayouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LMS\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>