<div id="appWrapper" class="app">

    
    <aside id="sidebar" class="sidebar">

        
        <div class="sb-brand">
            <div class="sb-brand-icon">
                <i class="fa-solid fa-graduation-cap"></i>
            </div>
            <span class="sb-brand-text">MyLMS</span>
            <button id="sidebarCollapseBtn" class="sb-collapse-btn" id="sidebarCollapseBtn" title="Collapse sidebar">
                <i class="fa-solid fa-angles-left"></i>
            </button>
        </div>

        
        <div class="sb-role-pill">
            <i class="fa-solid fa-shield-halved me-1"></i>
            <span class="sb-label">Admin Panel</span>
        </div>

        
        <nav class="sb-nav">

            
            <p class="sb-section-label"><span class="sb-label">Overview</span></p>
            <ul class="sb-list">
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" title="Dashboard"
                       class="sb-link <?php echo e(request()->routeIs('dashboard') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-gauge-high"></i></span>
                        <span class="sb-label">Dashboard</span>
                    </a>
                </li>
            </ul>

            
            <p class="sb-section-label"><span class="sb-label">People</span></p>
            <ul class="sb-list">

                <li class="sb-has-sub">
                    <button class="sb-link sb-toggle <?php echo e(request()->routeIs('teacher.*','admin.student.*','manage.role.*','admin.role','roles.permissions.*','admin.system.admins') ? 'sb-open' : ''); ?>"
                            data-target="#subUsers">
                        <span class="sb-icon"><i class="fa-solid fa-users"></i></span>
                        <span class="sb-label">User Management</span>
                        <i class="fa-solid fa-chevron-right sb-arrow"></i>
                    </button>
                    <ul class="sb-sub <?php echo e(request()->routeIs('teacher.*','admin.student.*','manage.role.*','admin.role','roles.permissions.*','admin.system.admins') ? 'show' : ''); ?>" id="subUsers">
                        <li>
                            <a href="<?php echo e(route('manage.role.view')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('manage.role.view') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-user-tag"></i>Manage Roles
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('teacher.Mangment.View')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('teacher.Mangment.View') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-chalkboard-user"></i>Teachers
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.student.managment')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('admin.student.managment') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-user-graduate"></i>Students
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.role')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('admin.role') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-user-shield"></i>Roles &amp; Permissions
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('roles.permissions.view')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('roles.permissions.view') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-shield-halved"></i>Access Control
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.system.admins')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('admin.system.admins') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-user-shield"></i>System Admins
                            </a>
                        </li>
                    </ul>
                </li>

            </ul>

            
            <p class="sb-section-label"><span class="sb-label">Academic</span></p>
            <ul class="sb-list">

                <li class="sb-has-sub">
                    <button class="sb-link sb-toggle <?php echo e(request()->routeIs('department.*','classDep.*','subjectDep.*') ? 'sb-open' : ''); ?>"
                            data-target="#subAcademic">
                        <span class="sb-icon"><i class="fa-solid fa-school"></i></span>
                        <span class="sb-label">Academic Setup</span>
                        <i class="fa-solid fa-chevron-right sb-arrow"></i>
                    </button>
                    <ul class="sb-sub <?php echo e(request()->routeIs('department.*','classDep.*','subjectDep.*') ? 'show' : ''); ?>" id="subAcademic">
                        <li>
                            <a href="<?php echo e(route('department.view')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('department.view') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-layer-group"></i>Departments
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('classDep.view')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('classDep.view') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-door-open"></i>Classes
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('subjectDep.view')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('subjectDep.view') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-book-open"></i>Subjects
                            </a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a href="<?php echo e(route('virtualRoom.view')); ?>"
                       class="sb-link <?php echo e(request()->routeIs('virtualRoom.view') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-video"></i></span>
                        <span class="sb-label">Virtual Classroom</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('course.index')); ?>"
                       class="sb-link <?php echo e(request()->routeIs('course.index') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-book"></i></span>
                        <span class="sb-label">Courses</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('assignments')); ?>"
                       class="sb-link <?php echo e(request()->routeIs('assignments') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-file-lines"></i></span>
                        <span class="sb-label">Assignments</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('attendence.view')); ?>"
                       class="sb-link <?php echo e(request()->routeIs('attendence.view') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-user-check"></i></span>
                        <span class="sb-label">Attendance</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('fee.view')); ?>"
                       class="sb-link <?php echo e(request()->routeIs('fee.view') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-money-bill-wave"></i></span>
                        <span class="sb-label">Fees</span>
                    </a>
                </li>

            </ul>

            
            <p class="sb-section-label"><span class="sb-label">System</span></p>
            <ul class="sb-list">

                <li class="sb-has-sub">
                    <button class="sb-link sb-toggle <?php echo e(request()->routeIs('financial.*','systemlogs.*') ? 'sb-open' : ''); ?>"
                            data-target="#subReports">
                        <span class="sb-icon"><i class="fa-solid fa-chart-pie"></i></span>
                        <span class="sb-label">Reports</span>
                        <i class="fa-solid fa-chevron-right sb-arrow"></i>
                    </button>
                    <ul class="sb-sub <?php echo e(request()->routeIs('financial.*','systemlogs.*') ? 'show' : ''); ?>" id="subReports">
                        <li>
                            <a href="<?php echo e(route('financial.view')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('financial.view') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-wallet"></i>Financial
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('systemlogs.view')); ?>"
                               class="sb-sub-link <?php echo e(request()->routeIs('systemlogs.view') ? 'sb-sub-active' : ''); ?>">
                                <i class="fa-solid fa-clipboard-list"></i>System Logs
                            </a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a href="<?php echo e(route('settings.view')); ?>"
                       class="sb-link <?php echo e(request()->routeIs('settings.view') ? 'sb-active' : ''); ?>">
                        <span class="sb-icon"><i class="fa-solid fa-gear"></i></span>
                        <span class="sb-label">Settings</span>
                    </a>
                </li>

            </ul>

        </nav>

        
        <div class="sb-profile">
            <div class="sb-profile-avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></div>
            <div class="sb-profile-info sb-label">
                <p class="sb-profile-name"><?php echo e(auth()->user()->name); ?></p>
                <p class="sb-profile-role">Administrator</p>
            </div>
            <form action="<?php echo e(route('logout')); ?>" method="POST" class="sb-label">
                <?php echo csrf_field(); ?>
                <button type="submit" class="sb-logout-btn" title="Sign out">
                    <i class="fa-solid fa-right-from-bracket"></i>
                </button>
            </form>
        </div>

    </aside>

    
    <header class="app-header" role="banner">
        <div class="header-left">
            <button id="mobileMenuBtn" class="hdr-icon-btn d-lg-none" type="button" aria-label="Open menu">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="search-input">
                <i class="fa-solid fa-magnifying-glass hdr-search-icon"></i>
                <input class="hdr-search-field" type="search" placeholder="Search..." aria-label="Search" />
            </div>
        </div>

        <div class="header-right">
            <button class="hdr-icon-btn" title="Notifications">
                <i class="fa-solid fa-bell"></i>
            </button>

            <div class="hdr-divider"></div>

            <div class="dropdown">
                <button class="hdr-profile-btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="hdr-avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></div>
                    <span class="hdr-name d-none d-md-inline"><?php echo e(auth()->user()->name); ?></span>
                    <i class="fa-solid fa-chevron-down hdr-caret d-none d-md-inline"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end hdr-dropdown">
                    <li class="hdr-dd-user">
                        <div class="hdr-dd-avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></div>
                        <div>
                            <div class="hdr-dd-name"><?php echo e(auth()->user()->name); ?></div>
                            <div class="hdr-dd-email"><?php echo e(auth()->user()->email); ?></div>
                        </div>
                    </li>
                    <li><hr class="dropdown-divider my-1"></li>
                    <li><a class="dropdown-item hdr-dd-item" href="<?php echo e(route('settings.view')); ?>"><i class="fa-solid fa-gear me-2"></i>Settings</a></li>
                    <li><hr class="dropdown-divider my-1"></li>
                    <li>
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="dropdown-item hdr-dd-item text-danger">
                                <i class="fa-solid fa-right-from-bracket me-2"></i>Sign out
                            </button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    
    <div id="sidebarOverlay" class="sb-overlay"></div>
<?php /**PATH D:\LMS\resources\views/partials/sidebar/admin.blade.php ENDPATH**/ ?>